NAVER LABS Manipulation Engineer — 포트폴리오 첨부 자산
RoArm-M3-Pro + VLA(SmolVLA/OpenVLA-OFT) + Isaac Sim 파이프라인
====================================================================

지원자가 직접 수행한 실로봇 데이터 수집 → 학습 → 배포 → sim2real → RL 분석
전 과정의 근거 이미지/영상입니다. 스토리 5개 폴더로 구성.

--------------------------------------------------------------------
[story1_vla_deploy]  VLA 데이터셋→학습→실로봇 배포 (담당업무 직격)
--------------------------------------------------------------------
- v6_ep00/20/45_pregrasp / _grasp .png : 실제 RoArm M3가 다양한 위치의
  스펀지를 파지하기 직전/파지 순간 (Azure Kinect 720P, 배포 성공 장면)
- data_gripper_analysis.png           : 50ep 데이터 gripper 개폐 분포 분석
- deep_trajectory.png / deep_zscores.png : 오프라인 추론 궤적 + z-score 검증
- v6_dataset_top_view.mp4             : v6 데이터셋(50ep/6942fr) top-view 영상
- pipeline_01_train_log_checkpoints.png : (실로그 렌더) SmolVLA v6 학습 로그
  loss 0.131->0.005 + 체크포인트 트리(005000~last) + B200 재현 EXIT_CODE=0
- pipeline_02_lerobot_schema.png      : (실파일 렌더) LeRobot v3.0 스키마
  meta/info.json — 50ep/6942fr, 720x1280 av1, state/action 6 motors
- pipeline_03_repo_scripts.png        : (실파일 렌더) collect→convert→train→deploy
  4개 핵심 스크립트 ls -lh + 파이프라인 흐름

--------------------------------------------------------------------
[story2_sim2real]  현실↔시뮬 정렬 / 카메라·테이블 캘리브레이션
--------------------------------------------------------------------
- sponge_check_..._vs_sim.png         : 실제 vs Isaac Sim 렌더 정렬 비교
- gamma_home_pose / gamma_layout_..._vs_sim.png : 자세·레이아웃 sim 정합
- marker_real_photo / marker_urdf_truth.png : 빨간 마커 실측 vs URDF 정답
- marker_placement_3d.png             : 3D 마커 배치
- kinect_calib_marker_A4.png          : Kinect↔RoArm hand-eye 캘리브
- stacking_initial_seed0_v3.png       : 우물정자 스태킹 씬 sim 초기 상태

--------------------------------------------------------------------
[story3_rl_analysis]  Isaac Lab PPO — 정직한 실패 진단
--------------------------------------------------------------------
- p6v12_learning_curves_4panel.png    : reward는 수렴하나 task gate 실패
- p6v12_failure_diagnosis.png         : joint-cap / overshoot 실패 진단
- p6v12_diagnosis_diagram.png         : 원인(reset-distribution) 구조도
- p6v12_vs_p6v11_bar.png              : 변형 간 비교
- p6v12 / p6v13 / p6v14b_rollout.mp4  : PPO rollout 영상

--------------------------------------------------------------------
[story4_visual_dataset]  대규모 sim 비주얼 데이터셋 + 자동 라벨 QA
--------------------------------------------------------------------
- professor_review_contact_sheet_d234.png : 1000ep 비주얼 데이터 컨택트시트
- camera_fail_contact_sheet.png       : 카메라 컨트랙트 위반 자동 격리(QA)

--------------------------------------------------------------------
[story5_stacking]  스태킹 태스크 설계
--------------------------------------------------------------------
- well_pattern_complete_v2 / layer1_v2.png : 2층 우물정자 타워 기하 설계
- stacking_demo_seed42.png            : 절차적 스태킹 데모 초기 상태
